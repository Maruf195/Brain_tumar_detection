#include <iostream>
#include <thread>
#include <chrono>
#include <vector>

void do_work(int process_number) {
    auto start_time = std::chrono::high_resolution_clock::now();  
    std::cout << "[Process " << process_number << "] Starting work.\n";

    int i = 0;
    for (int j = 0; j < 20000000; ++j) {
        i += 1;
    }

    auto end_time = std::chrono::high_resolution_clock::now();  
    std::chrono::duration<double> response_time = end_time - start_time;
    std::cout << "[Process " << process_number << "] Finished work. Response time: "
              << response_time.count() << " seconds\n";
}

int main() {
    const int num_processes = 5;
    std::vector<std::thread> threads;

    for (int process_number = 1; process_number <= num_processes; ++process_number) {
        threads.emplace_back(do_work, process_number);
        std::cout << "[Process " << process_number << "] Started.\n";
    }

    int completed_count = 0;
    for (int process_number = 0; process_number < num_processes; ++process_number) {
        threads[process_number].join();  
        ++completed_count;
        std::cout << "[Process " << (process_number + 1) << "] Joined. Total processes joined: "
                  << completed_count << "/" << num_processes << "\n";
    }

    std::cout << "All " << completed_count << " processes completed.\n";
    return 0;
}

