program extended_parallel_work
    use omp_lib
    implicit none
    integer, parameter :: num_processes = 5
    integer :: i, j, process_number
    real :: start_time, end_time, response_time
    real, dimension(num_processes) :: response_times
    real :: total_time, avg_time

    total_time = 0.0

    
    process_number = omp_get_thread_num() + 1  

    start_time = omp_get_wtime()
    print *, '[Process ', process_number, '] Starting work.'

    
    i = 0
    do j = 1, 20000000 * process_number
        i = i + 1
    end do

    end_time = omp_get_wtime()
    response_time = end_time - start_time
    response_times(process_number) = response_time